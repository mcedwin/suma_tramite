<!-- <div id="elard"> -->
		<input type="hidden" id="baseurl" value="<?php echo base_url() ?>">
		
</body>
</html>