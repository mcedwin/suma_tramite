			<div id="caja">
				<h2>&iexcl;Ups! modulo no encontrado</h2>
				<p><?= $mensaje ?></p>
			</div>